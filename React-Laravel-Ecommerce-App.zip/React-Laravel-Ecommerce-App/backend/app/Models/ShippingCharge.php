<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ShippingCharge extends Model
{
    protected $fillable = [
        'area_name',
        'charge',
    ];

    protected $casts = [
        'charge' => 'decimal:2',
    ];
}
